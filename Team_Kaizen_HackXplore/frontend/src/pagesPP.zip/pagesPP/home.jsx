import React from 'react'

const home = () => {
  return <div>home</div>
}

export default home
